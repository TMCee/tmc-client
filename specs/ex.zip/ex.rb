def method
  0
end